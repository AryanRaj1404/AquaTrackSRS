import { useEffect, useMemo, useState } from "react";
import toast from "react-hot-toast";

import {
  Building2,
  CheckCircle2,
  Loader2,
  Plus,
  Save,
  X,
} from "lucide-react";

import AdminPageShell from "../components/AdminPageShell";
import EmptyState from "../components/EmptyState";
import StatCard from "../components/StatCard";
import {
  createApartment,
  getApartments,
} from "../services/apartmentService";

const initialForm = {
  apartmentName: "",
  address: ""
};

function Apartments() {
  const [apartments, setApartments] = useState([]);
  const [query, setQuery] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(initialForm);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    loadApartments();
  }, []);

  const loadApartments = async () => {
    try {
      setIsLoading(true);

      const data = await getApartments();

      setApartments(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Apartment fetch error:", error);

      setApartments([]);

      toast.error(
        "Unable to load apartments."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const filteredApartments = useMemo(() => {
    if (!query.trim()) {
      return apartments;
    }

    const keyword = query.toLowerCase();

    return apartments.filter((apartment) => {
      return (
        apartment.name?.toLowerCase().includes(keyword) ||
        apartment.address?.toLowerCase().includes(keyword)
      );
    });
  }, [apartments, query]);

  const handleChange = (event) => {
    const { name, value } = event.target;

    setForm((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  const validateForm = () => {
    if (!form.apartmentName.trim()) {
      toast.error("Apartment name is required.");
      return false;
    }

    if (!form.address.trim()) {
      toast.error("Address is required.");
      return false;
    }

    return true;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!validateForm()) {
      return;
    }

    const apartmentPayload = {
      name: form.apartmentName.trim(),
      address: form.address.trim(),
    };

    setIsSubmitting(true);

    const loadingToast = toast.loading("Registering apartment...");

    try {
      const savedApartment = await createApartment(apartmentPayload);

      setApartments((previous) => [savedApartment, ...previous]);

      toast.success("Apartment created successfully.", {
        id: loadingToast,
      });

      setForm(initialForm);
      setShowForm(false);
    } catch (error) {
      console.error("Apartment create error:", error);

      toast.error(
        "Failed to register apartment.Please try again.",
        {
          id: loadingToast,
        }
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    setForm(initialForm);
    setShowForm(false);
  };

  return (
    <AdminPageShell
      title="Apartment Management"
      description="Manage apartment complexes and organize households."
      searchValue={query}
      onSearchChange={setQuery}
      searchPlaceholder="Search apartments..."
      action={
        <button
          type="button"
          className="mg-primary-button"
          onClick={() => setShowForm(true)}
        >
          <Plus size={18} />
          Register Apartment
        </button>
      }
    >
      <section className="mg-summary-grid">
        <StatCard
          icon={Building2}
          title="Total Apartments"
          value={apartments.length}
          description="Registered apartment complexes"
        />

        <StatCard
          icon={Building2}
          title="Total Households"
          value="0"
          description="Will update automatically"
        />

        <StatCard
          icon={CheckCircle2}
          title="Residents"
          value="0"
          description="Registered residents"
        />

        <StatCard
          icon={Building2}
          title="Latest Apartment"
          value={
            apartments.length > 0
              ? apartments[0].name
              : "-"
          }
          description={
            apartments.length > 0
              ? apartments[0].address
              : "No apartments yet"
          }
        />
      </section>

      {showForm && (
        <section className="mg-panel" style={{ marginBottom: "20px" }}>
          <div className="mg-toolbar">
            <div>
              <h2>Register Apartment</h2>
              <p>
                Enter the apartment details below.
              </p>
            </div>

            <button
              type="button"
              className="mg-cancel-button"
              onClick={handleCancel}
              disabled={isSubmitting}
            >
              <X size={16} />
              Close
            </button>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="mg-form-grid">
              <div className="mg-form-group mg-form-group-full">
                <label htmlFor="apartmentName">Apartment Name</label>

                <input
                  id="apartmentName"
                  name="apartmentName"
                  type="text"
                  value={form.apartmentName}
                  onChange={handleChange}
                  placeholder="Example: Green Valley Apartments"
                  disabled={isSubmitting}
                />
              </div>

              <div className="mg-form-group">
                <label htmlFor="address">Address</label>

                <input
                  id="address"
                  name="address"
                  type="text"
                  value={form.address}
                  onChange={handleChange}
                  placeholder="Sector-62, Noida"
                  disabled={isSubmitting}
                />
              </div>

            </div>

            <div className="mg-modal-actions">
              <button
                type="button"
                className="mg-cancel-button"
                onClick={handleCancel}
                disabled={isSubmitting}
              >
                <X size={17} />
                Cancel
              </button>

              <button
                type="submit"
                className="mg-primary-button"
                disabled={isSubmitting}
              >
                <Save size={17} />
                {isSubmitting ? "Registering..." : "Register Apartment"}
              </button>
            </div>
          </form>
        </section>
      )}

      <section className="mg-panel">
        <div className="mg-toolbar">
          <div>
            <h2>Apartment Records</h2>
            <p>
              All registered apartment complexes are listed below.
            </p>
          </div>
        </div>

        {isLoading ? (
          <div className="mg-empty-state">
            <Loader2 size={36} className="animate-spin" />
            <h3>Loading apartments</h3>
            <p>Please wait while apartment data is fetched.</p>
          </div>
        ) : filteredApartments.length > 0 ? (
          <div className="mg-table-wrapper">
            <table className="mg-table">
              <thead>
                <tr>
                  <th>Apartment Name</th>
                  <th>Address</th>
                  <th>Households</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {filteredApartments.map((apartment) => (
                  <tr key={apartment.id || apartment.name}>
                    <td>
                      <span className="mg-table-primary">
                        {apartment.name}
                      </span>
                    </td>
                    <td>{apartment.address}</td>
                      <td>
                        <span className="mg-badge">Coming Soon</span>
                      </td>

                      <td>
                        <button
                          type="button"
                          className="mg-secondary-button"
                          onClick={() =>
                            toast("Apartment details coming soon.")
                          }
                        >
                          View
                        </button>
                      </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon={Building2}
            title="No apartments found"
            description="Create your first apartment to begin managing households."
          />
        )}
      </section>
    </AdminPageShell>
  );
}

export default Apartments;