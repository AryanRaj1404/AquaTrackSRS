import { useEffect, useState } from "react";

import {
    RefreshCw,
    TriangleAlert,
    Clock3,
    CheckCircle2,
    Bell,
    Filter,
} from "lucide-react";

import AdminPageShell from "../components/AdminPageShell";
import StatCard from "../components/StatCard";
import Pagination from "../components/Pagination";
import SkeletonTable from "../components/SkeletonTable";
import EmptyState from "../components/EmptyState";

import {
    getAllAlerts,
    getAlertSummary,
} from "../services/alertService";

export default function Alerts() {
    const [alerts,setAlerts]=useState({
        content:[],
        totalPages:0,
        totalElements:0,
    });

    const [summary, setSummary] = useState({
        critical:0,
        pending:0,
        acknowledged:0,
        total:0,
    });

    const [loading,setLoading]=useState(true);

    const [page,setPage]=useState(0);

    const [status,setStatus]=useState("ALL");

    async function loadAlerts(){

        setLoading(true);

        try{

            const [summaryData,pageData]=await Promise.all([

                getAlertSummary(),

                getAllAlerts(page, 10,status)

            ]);

            setSummary({
                critical: summaryData.criticalAlerts,
                pending: summaryData.pendingAlerts,
                acknowledged: summaryData.resolvedToday,
                total:
                    summaryData.pendingAlerts +
                    summaryData.resolvedToday,
            });

            setAlerts(pageData);

            console.log(summaryData)
            console.log(pageData)

        }

        finally{

            setLoading(false);

        }

    }

    useEffect(()=>{

        loadAlerts();

    },[page,status]);


  return (
    <AdminPageShell

    title="Alert Management"

    description="Monitor, investigate and acknowledge alerts generated across all apartments."

    action={

    <button

    className="mg-primary-button flex items-center gap-2"

    onClick={loadAlerts}

    >

    <RefreshCw size={18}/>

    Refresh Alerts

    </button>

    }

    >

      <div className="space-y-8">

       

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">

<StatCard

icon={TriangleAlert}

title="Critical"

value={summary.critical}

description="Leak alerts"

animatedValue

/>

<StatCard

icon={Clock3}

title="Pending"

value={summary.pending}

description="Need review"

animatedValue

/>

<StatCard

icon={CheckCircle2}

title="Acknowledged"

value={summary.acknowledged}

description="Reviewed"

animatedValue

/>

<StatCard

icon={Bell}

title="Total"

value={summary.total}

description="Generated alerts"

animatedValue

/>

</div>

        <div className="rounded-3xl bg-white border border-slate-200 p-6">

<div className="flex flex-wrap gap-4 items-center justify-between">



<select

value={status}

onChange={(e)=>{

setPage(0);

setStatus(e.target.value);

}}

className="rounded-xl border border-slate-200 px-4 py-3"

>

<option value="ALL">

All Alerts

</option>

<option value="PENDING">

Pending

</option>

<option value="ACKNOWLEDGED">

Acknowledged

</option>

</select>

</div>

</div>

        <div className="rounded-3xl bg-white border border-slate-200 overflow-hidden">

{

loading ?

<SkeletonTable rows={8}/>

:

alerts.content.length===0 ?

<EmptyState

title="No alerts found"

description="Everything looks healthy."

/>

:
<>
<table className="w-full">

<thead className="bg-slate-50 border-b border-slate-200">

<tr>

<th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
Alert
</th>

<th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
Apartment
</th>

<th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
Household
</th>

<th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
Status
</th>

<th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-500">
Triggered On
</th>

<th className="px-6 py-4 text-right text-xs font-semibold uppercase tracking-wider text-slate-500">
Action
</th>

</tr>

</thead>

<tbody className="divide-y divide-slate-100">

{

alerts.content.map(alert=>(

<tr key={alert.id} className="hover:bg-slate-50 transition-colors">

<td className="px-6 py-5">{alert.alertType === "ANOMALY_LEAK"
    ? "Possible Water Leak"
    : "High Consumption"}</td>

<td className="px-6 py-5">{alert.apartmentName}</td>

<td className="px-6 py-5">{alert.householdName}</td>

<td className="px-6 py-5">

<span
className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${
alert.acknowledged
? "bg-emerald-100 text-emerald-700"
: "bg-red-100 text-red-700"
}`}
>

{alert.acknowledged ? "Acknowledged" : "Pending"}

</span>

</td>

<td className="px-6 py-5">

{alert.triggeredOn}

</td>

<td className="px-6 py-5">

<button className="font-semibold text-teal-600 hover:text-teal-700">

View

</button>

</td>

</tr>

))

}

</tbody>

</table>

<div className="border-t border-slate-200 px-6 py-4">

<Pagination
page={page}
pageData={alerts}
pageSize={10}
currentCount={alerts.content?.length ?? 0}
label="alerts"
onPrevious={() => setPage(page - 1)}
onNext={() => setPage(page + 1)}
onPageChange={setPage}
/>

</div>
</>

}
</div>

</div>

    </AdminPageShell>
  );
}