import React, { useState, useEffect } from "react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from "recharts";
import { Activity, Building2, PieChart as PieChartIcon, RefreshCw } from "lucide-react";
import adminDashboardService from "../../services/adminDashboardService";

const COLORS = {
  darkTeal: "#06334b",
  teal: "#075d78",
  primaryTeal: "#0781a5",
  lightBlue: "#eef7fb",
  gray: "#f1f5f9",
  textGray: "#64748b"
};



const CustomTooltip = ({ active, payload, label, unit = "" }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 border border-slate-100 shadow-[0_4px_12px_-2px_rgba(6,51,75,0.1)] rounded-lg text-sm">
        <p className="font-semibold text-[#06334b] mb-1">{label}</p>
        {payload.map((entry, index) => (
          <div key={index} className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }}></div>
            <span className="text-slate-600 capitalize">Consumption:</span>
            <span className="font-bold text-[#06334b]">
              {Number(entry.value).toLocaleString()}{unit}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function AdminDashboardCharts() {
  const [chartData, setChartData] = useState([]);
  const [dataApartment, setDataApartment] = useState([]);
  const [dataUsage, setDataUsage] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [viewMode, setViewMode] = useState("daily");
  const [timeRange, setTimeRange] = useState("1M");
  const [lastUpdated, setLastUpdated] = useState(new Date());

 

  const fetchChartsData = async () => {
    try {
      setError(null);
      const [consumption, apartment, usage] = await Promise.all([
          adminDashboardService.getConsumptionTrend(viewMode, timeRange),
          adminDashboardService.getApartmentConsumption(),
          adminDashboardService.getUsageStatus()
      ]);
      setChartData(consumption);
      setDataApartment(
        apartment
          .sort((a, b) => b.totalConsumption - a.totalConsumption)
          .slice(0, 10)
      );
      setDataUsage(usage);
      setLastUpdated(new Date());
    } catch (err) {
      setError("Failed to fetch chart data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchChartsData();
  }, [viewMode, timeRange]);

  useEffect(() => {
      const interval = setInterval(fetchChartsData, 30000);
      return () => clearInterval(interval);
  }, []);

  if (loading && chartData.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-96 w-full bg-white rounded-[30px] shadow-[0_4px_20px_-4px_rgba(6,51,75,0.05)] border border-slate-100">
        <RefreshCw size={32} className="animate-spin text-teal-700 mb-4" />
        <p className="text-[#075d78] font-medium">Loading analytics...</p>
      </div>
    );
  }

  if (error && chartData.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-96 w-full bg-red-50 rounded-[30px] border border-red-200">
        <p className="text-red-600 font-medium">{error}</p>
        <button 
          onClick={fetchChartsData}
          className="mt-4 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200"
        >
          Retry
        </button>
      </div>
    );
  }

  

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 w-full relative">
      
      {/* 1. Monthly Water Consumption Chart */}
      <div className="bg-white p-7 rounded-[30px] shadow-[0_4px_20px_-4px_rgba(6,51,75,0.05)] border border-slate-100 lg:col-span-2">
        <div className="flex items-start justify-between mb-6 border-b border-slate-100 pb-4">

    <div className="flex items-center gap-3">

        <div className="p-2 bg-teal-50 text-teal-700 rounded-xl">
            <Activity size={22} />
        </div>

        <div>

            <p className="text-[10px] font-bold uppercase tracking-[0.30em] text-teal-600 mb-1">
                Analytics
            </p>

            <h3 className="text-xl font-bold text-[#06334b]">
                Consumption Trends
            </h3>

            <p className="text-sm text-[#075d78]">
                Analyze historical water consumption
            </p>

        </div>

    </div>

    <div className="flex flex-col items-end gap-2 bg-slate-50 rounded-2xl p-3">

        {/* Daily Monthly */}

        <div className="flex bg-slate-100 rounded-xl p-1">

            <button
                onClick={() => setViewMode("daily")}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                    viewMode === "daily"
                        ? "bg-teal-700 text-white shadow"
                        : "text-slate-500 hover:text-slate-800"
                }`}
            >
                Daily
            </button>

            <button
                onClick={() => setViewMode("monthly")}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                    viewMode === "monthly"
                        ? "bg-teal-700 text-white shadow"
                        : "text-slate-500 hover:text-slate-800"
                }`}
            >
                Monthly
            </button>

        </div>

        {/* Time Buttons */}

        <div className="flex gap-1">

            {["1M","3M","6M","1Y"].map((range)=>(
                <button
                    key={range}
                    onClick={()=>setTimeRange(range)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-200 ${
                        timeRange===range
                        ? "bg-teal-700 text-white"
                        : "text-slate-500 hover:bg-slate-100"
                    }`}
                >
                    {range}
                </button>
            ))}

        </div>

    </div>

</div>
<div className="h-[360px] w-full">

  {chartData.length === 0 ? (

    <div className="flex items-center justify-center h-full text-slate-400">
      No data available
    </div>

  ) : (

    <ResponsiveContainer width="100%" height="100%">

      <AreaChart
        data={chartData}
        margin={{
          top: 20,
          right: 20,
          left: 0,
          bottom: 15,
        }}
      >

        <defs>
          <linearGradient
            id="consumptionGradient"
            x1="0"
            y1="0"
            x2="0"
            y2="1"
          >
            <stop
              offset="5%"
              stopColor={COLORS.primaryTeal}
              stopOpacity={0.35}
            />

            <stop
              offset="95%"
              stopColor={COLORS.primaryTeal}
              stopOpacity={0}
            />
          </linearGradient>
        </defs>

        <CartesianGrid
          strokeDasharray="2 6"
          vertical={false}
          stroke={COLORS.gray}
        />

        <XAxis
          dataKey="label"
          axisLine={false}
          tickLine={false}
          minTickGap={50}
          tick={{ fontSize: 13, fill: "#64748b" }}
          tickFormatter={(value) => {
            const date = new Date(value);

            if (viewMode === "daily") {
              return date.toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
              });
            }

            return date.toLocaleDateString("en-IN", {
              month: "short",
              year: "numeric",
            });
          }}
        />

        <YAxis
          axisLine={false}
          tickLine={false}
        />

        <Tooltip content={<CustomTooltip unit=" KL" />} />

        <Area
          dot={{
            r: 5,
            strokeWidth: 2,
            fill: "#0781a5",
            stroke: "#ffffff"
          }}
          activeDot={{
              r: 7
          }}
          type="monotone"
          dataKey="totalConsumption"
          stroke={COLORS.primaryTeal}
          strokeWidth={4}
          fill="url(#consumptionGradient)"
          isAnimationActive
          animationDuration={900}
          animationEasing="ease-out"
        />

      </AreaChart>

    </ResponsiveContainer>

  )}

</div>
</div>

      {/* 2. Apartment-wise Consumption Chart */}
      <div className="bg-white p-7 rounded-[30px] shadow-[0_4px_20px_-4px_rgba(6,51,75,0.05)]">
        <div className="flex items-center gap-2 mb-6 border-b border-slate-100 pb-3">
          <div className="p-1.5 bg-teal-50 text-teal-700 rounded-lg">
            <Building2 size={20} />
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.28em] text-teal-600 mb-1">
                Analytics
            </p>
            <h3 className="font-semibold text-[#06334b]">Apartment-wise Consumption</h3>
            <p className="text-xs text-[#075d78]">Compares water consumption between apartments/blocks</p>
          </div>
        </div>
        <div className="h-64 w-full">
          {dataApartment.length === 0 ? (
            <div className="flex items-center justify-center h-full text-slate-400">No data available</div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart 
              data={dataApartment} 
              layout="vertical" 
              barCategoryGap="25%"
              margin={{ 
                top: 0, 
                right: 20, 
                left: 0, 
                bottom: 0 
                }}>
                <CartesianGrid strokeDasharray="2 6" horizontal={false} stroke={COLORS.gray} />
                <XAxis
                  type="number"
                  axisLine={false}
                  tickLine={false}
                  tick={{
                      fontSize: 12,
                      fill: COLORS.textGray,
                  }}
                />
                <YAxis
                  type="category"
                  dataKey="apartmentName"
                  interval={0}
                  axisLine={false}
                  tickLine={false}
                  width={100}
                  tick={{
                      fontSize: 12,
                      fill: COLORS.textGray,
                  }}
                />
                <Tooltip content={<CustomTooltip unit=" KL" />} cursor={{ fill: COLORS.lightBlue }} />
                <Bar 
                  dataKey="totalConsumption" 
                  name="Consumption" 
                  fill={COLORS.teal} 
                  radius={[0, 6, 6, 0]} 
                  barSize={12}
                >
                  {dataApartment.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.totalConsumption > 1500 ? COLORS.darkTeal : COLORS.primaryTeal} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* 3. Usage Status Summary Chart */}
      <div className="bg-white p-7 rounded-[30px] shadow-[0_4px_20px_-4px_rgba(6,51,75,0.05)] border border-slate-100">
        <div className="flex items-center gap-2 mb-6 border-b border-slate-100 pb-3">
          <div className="p-1.5 bg-teal-50 text-teal-700 rounded-lg">
            <PieChartIcon size={20} />
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[0.28em] text-teal-600 mb-1">
                Analytics
            </p>
            <h3 className="font-semibold text-[#06334b]">Usage Status Summary</h3>
            <p className="text-xs text-[#075d78]">Normal, High, and Critical usage distribution</p>
          </div>
        </div>
        <div className="h-64 w-full flex items-center justify-center relative">
          {dataUsage.length === 0 ? (
            <div className="flex items-center justify-center h-full text-slate-400">No data available</div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={dataUsage}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={90}
                    paddingAngle={4}
                    dataKey="count"
                    nameKey="status"
                    stroke="none"
                  >
                    {dataUsage.map((entry, index) => {
                      let color = COLORS.primaryTeal;
                      if (entry.status === 'High Usage') color = COLORS.teal;
                      if (entry.status === 'Critical Usage') color = COLORS.darkTeal;
                      return <Cell key={`cell-${index}`} fill={color} />;
                    })}
                  </Pie>
                  <Tooltip 
                    formatter={(value, name) => [value, name]}
                    contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Legend 
                    verticalAlign="bottom" 
                    height={36}
                    iconType="circle"
                    formatter={(value) => <span className="text-slate-600 text-sm font-medium">{value}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
              
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mb-8">
                <span className="text-2xl font-bold text-[#06334b]">
                  {dataUsage.reduce((acc, curr) => acc + curr.count, 0)}
                </span>
                <span className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">Usage Records</span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}